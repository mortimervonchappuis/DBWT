<?php
/**
 * Created by PhpStorm.
 * User: mortimer
 * Date: 11/5/20
 * Time: 6:17 PM
 *
 *  - Praktikum DBWT. Autoren:
 *  - Dominik, Bien, 3149135
 *  - Botho Karl Mortimer, von Chappuis, 3146023
 */
function addiere($a, $b=0){
    return $a + $b;
}
?>