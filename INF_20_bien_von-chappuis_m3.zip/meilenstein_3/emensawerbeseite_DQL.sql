USE emensawerbeseite;

SELECT COUNT(*) FROM gericht;
SELECT COUNT(*) FROM allergen;
SELECT COUNT(*) FROM kategorie;
SELECT COUNT(*) FROM gericht_hat_allergen;
SELECT COUNT(*) FROM gericht_hat_kategorie;