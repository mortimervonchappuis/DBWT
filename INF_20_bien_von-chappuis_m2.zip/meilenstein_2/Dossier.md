# Dossier DBWT Meilenstein 2

| Aufgabe | Geschätzte Zeit | Tatsächliche Zeit |
| ------- | --------------- | ----------------- |
| 1       | 5 min           | 5 min             |
| 2       | 10 min          | 23 min            |
| 3       | 2 min           | 2 min             |
| 4       |                 |                   |
| 5       | 30 min          | 60 min            |
| 6       | 60 min          | 60 min            |
| 7       |                 |                   |
