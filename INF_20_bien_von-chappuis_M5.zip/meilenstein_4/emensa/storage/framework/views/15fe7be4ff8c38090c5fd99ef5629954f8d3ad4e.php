
<footer class="fuss">
    <hr>
    <ul class="fuss-list">
        <li>&copy; E-Mensa GmbH</li>
        <li>Dominik Bien & Mortimer von Chappuis</li>
        <li><a href="impressum.html">Impressum</a></li>
    </ul>
</footer>
<?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/Layout/footer.blade.php ENDPATH**/ ?>