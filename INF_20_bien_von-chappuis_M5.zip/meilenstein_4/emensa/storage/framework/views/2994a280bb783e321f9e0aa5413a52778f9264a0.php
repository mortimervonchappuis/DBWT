<?php $__env->startSection('title'); ?>
    Anmeldung
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class='anmeldung' style="text-align: center">
        <h2 class="headline-bold">Anmeldung</h2>
        <form method="post" action="/verify">
            <?php echo csrf_field(); ?>
            <input <?php if (isset($_GET['fail'])) echo'style="background: #ff3333"' ?> type="email" name="e-mail" placeholder="person@example.web">
            <br>
            <input <?php if (isset($_GET['fail'])) echo'style="background: #ff3333"' ?> type="password" name="password" placeholder="············">
            <br>
            <input type="submit" value="Anmeldung">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/Homepage/anmeldung.blade.php ENDPATH**/ ?>