@extends('Layout/layout')
@section('title')
    About Us
@endsection
@section('content')

    <div class="fakenews" id="info" style="  display: flex;  flex-direction: column;  justify-content: space-between;">
        <h2 class="headline-bold" style="align-self: center ;">Das ist uns wichtig!!!</h2>
        <div style="text-align: center">
            <p>Beste frische saisonale Zutaten</p>
            <p>Ausgewogene abwechslungsreiche Gerichte</p>
            <p>Sauberkeit</p>
        </div>
    </div>

    <h2 class="last-headline-bold">Wir freuen uns auf Ihren Besuch!</h2>
    </div>
@endsection
