@extends('examples/layout/layout')

@section('title')
    <title>Page 2</title>
@endsection

@section('header')
    <h4>Hi im the header of the Second Page</h4>
@endsection
@section('main')
    <p>There is no fun in this</p>
@endsection
@section('footer')
    <h5>Ask me if I'm the footer</h5>
@endsection
