<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gerichte extends Model
{
    protected $attributes=['gericht_id'];

    use HasFactory;
}
