php artisan migrate:[fresh] --seed

