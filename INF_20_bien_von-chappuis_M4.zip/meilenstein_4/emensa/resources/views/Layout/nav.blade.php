<header class="site-head" >
    <nav class="row" >
        <!--logo-->
        <div class="col-header logo">
            <!--<img class="logo-img" id=logo src="e-mensa-logo.png"> -->
            <a href="/home"><h1>E-Mensa Logo</h1></a>
        </div>
        <!--Menu-Navigation-->
        <div class=col-header>
            <ul id="menu-hauptnavigation" class="menu">
                <li class="menu-item" >
                    <a href="/">Ankündigung</a>
                </li>
                <li class="menu-item">
                    <a href="/meals">Speisen</a>
                </li>
                <li class="menu-item">
                    <a href="">Zahlen</a>
                </li>
                <li class="menu-item">
                    <a href="/contact">Kontakt</a>
                </li>
                <li class="menu-item">
                    <a href="/about">Über uns</a>
                </li>
            </ul>
        </div>
    </nav>
    <hr>
</header>
