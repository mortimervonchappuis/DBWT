
<footer class="fuss">
    <hr>
    <ul class="fuss-list">
        <li>&copy; E-Mensa GmbH</li>
        <li>Dominik Bien & Mortimer von Chappuis</li>
        <li><a href="impressum.html">Impressum</a></li>
    </ul>
</footer>
