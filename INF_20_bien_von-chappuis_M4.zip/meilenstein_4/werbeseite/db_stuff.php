<?php
/**
 * Praktikum DBWT. Autoren:
 * Dominik, Bien, 3149135
 * Botho Karl Mortimer, von Chappuis, 3146023
 * Date: 12/2/20
 * Time: 9:24 PM
 */


$port = 3306;
$link = mysqli_connect("127.0.0.1", "root", "root","emensawerbeseite", $port);
?>