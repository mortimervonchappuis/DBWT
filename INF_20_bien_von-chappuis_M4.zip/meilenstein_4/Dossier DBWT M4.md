# Dossier DBWT M4

| Aufgabe | Geschäzt          | Tatsächlich |
| ------- | ----------------- | ----------- |
| $1$     |                   |             |
| $2$     |                   |             |
| $3$     |                   |             |
| $4$     |                   |             |
| $5$     | 10 min            | 120 min     |
| $6$     | 30 min            | 30 min      |
| $7$     | 60 min            | 120 min     |
| $8$     |                   |             |
| $9$     |                   |             |

