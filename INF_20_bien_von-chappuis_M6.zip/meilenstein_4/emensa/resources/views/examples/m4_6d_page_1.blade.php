@extends('examples/layout/layout')

@section('title')
    <title>Page 1</title>
@endsection

@section('header')
<h4>Hi im the header</h4>
@endsection
@section('main')
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet, animi assumenda deserunt dolorem doloribus ducimus eius fuga, laborum laudantium nam necessitatibus numquam officia porro, provident quae quod rem voluptas voluptate?</p>
@endsection
@section('footer')
<h5>I'm the footer</h5>
@endsection
