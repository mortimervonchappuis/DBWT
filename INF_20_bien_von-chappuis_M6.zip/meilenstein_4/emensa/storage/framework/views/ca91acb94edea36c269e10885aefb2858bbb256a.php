<header class="meal-nav" style="display: flex;justify-content: center;">
    <nav class="row" style="" >
        <!--Menu-Navigation-->
            <ul id="menu-mealnavigation" class="menu" style="width: auto;margin: 0;">
                <li class="menu-item" >
                    <a href="/meals">Alle</a>
                </li>
                <li class="menu-item">
                    <a href="/meals/Suppen">Suppen</a>
                </li>
                <li class="menu-item">
                    <a href="/meals/User">Benutzer Anmeldungen</a>
                </li>
            </ul>
    </nav>
</header>
<?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/mealfilter/mealnav.blade.php ENDPATH**/ ?>