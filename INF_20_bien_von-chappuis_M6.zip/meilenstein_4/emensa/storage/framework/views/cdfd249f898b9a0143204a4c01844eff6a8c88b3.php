<?php $__env->startSection('title'); ?>
    News
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="s-box" id="neuigkeiten">
        <h2 class="headline-bold">Bald gibt es Essen auch online ;)</h2>
        <p id="fliesstext">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            <br>
            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>

    <div class="row">
    <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col" style="max-width: 200px;">
            <img width="200" height="200" src="img/gerichte/<?php echo e($meal->bildname ?? '00_image_missing.jpg'); ?>">
            <p style="text-align: center;"><?php echo e($meal->name); ?><?php
                    if (isset($_SESSION['user'])) echo "<br><a style='text-align: center;' href='bewertung?id=".$meal->id."'>bewerten</a>";
                ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <div class="box">
        <h2>Meinungen unserer Gäste</h2>
        <?php $__currentLoopData = $bewertungen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bewertung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="engraved">
                <div class="b-img">
                    <img src="img/gerichte/<?php echo e($bewertung->bildname ?? '00_image_missing.jpg'); ?>" width="250" height="250">
                </div>
                <div class="b-cont">
                    <h3 style="display: inline;"><?php echo e($bewertung->name); ?></h3>
                    <?php
                        if (isset($_SESSION['admin']) && $_SESSION['admin']){
                            echo "<a href='/engrave?id=".$bewertung->id."'><button style='background: #cccccc; float: right; color: white; border: black solid 1px;'>🕭</button></a>";

                        }
                        if (isset($_SESSION['user']) && $_SESSION['user'] == $bewertung->E_Mail){
                        echo "<a href='/delete?id=".$bewertung->id."'><button style='background: #bd0000; float: right; color: white; border: black solid 1px;'>🗑</button></a>";
                        }
                    ?>
                    <div class="b-cont-cont">
                        <p style="display: inline;"><big><?php echo e($bewertung->E_Mail); ?></big></p>
                        <div class="star">
                            <big>
                                <?php
                                    for($i=0; $i<5; $i++){
                                    if ($i < $bewertung->sterne)
                                    echo '★';
                                    else
                                    echo '☆';
                                    }
                                ?></big></div>
                        <p><small><?php echo e($bewertung->beschreibung); ?></small></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/Homepage/news.blade.php ENDPATH**/ ?>