<?php $__env->startSection('title'); ?>
    About Us
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="fakenews" id="info" style="  display: flex;  flex-direction: column;  justify-content: space-between;">
        <h2 class="headline-bold" style="align-self: center ;">Das ist uns wichtig!!!</h2>
        <div style="text-align: center">
            <p>Beste frische saisonale Zutaten</p>
            <p>Ausgewogene abwechslungsreiche Gerichte</p>
            <p>Sauberkeit</p>
        </div>
    </div>

    <h2 class="last-headline-bold">Wir freuen uns auf Ihren Besuch!</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/Homepage/about.blade.php ENDPATH**/ ?>