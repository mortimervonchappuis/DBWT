<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('mealfilter.mealnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table style="margin: auto">
        <thead>
        <tr>
            <th>Benutzer</th>
            <th>Anmeldungen</th>
        </tr>
        </thead>

        <tbody>

        <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->E_Mail); ?></td>
                <td><?php echo e($user->anzahl_anmeldungen); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/mealfilter/userLogins.blade.php ENDPATH**/ ?>