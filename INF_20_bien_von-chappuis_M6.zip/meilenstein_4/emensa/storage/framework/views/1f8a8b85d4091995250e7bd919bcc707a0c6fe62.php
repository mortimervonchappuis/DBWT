<?php $__env->startSection('title'); ?>
    Meal List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('mealfilter.mealnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="preis" id="speisen" >
        <h2 class="headline-bold" style="text-align: center">Köstlichkeiten, die Sie erwarten!</h2>
        <table class=\"preis\" style="margin: auto">
            <thead>
            <tr>
                <th class=\"preis-head\">
                    Gericht
                </th>
                <th class=\"preis-head\">
                    Preis intern
                    <small>in €</small>
                </th>
                <th class=\"preis-head\">
                    Preis extern
                    <small>in €</small>

                </th>
                <th class=\"preis.head\">
                    Allergene
                </th>
            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $mealList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=\"preis-schrift\">
                        <?php echo e($meal->name); ?>

                    </td>
                    <td class=\"preis-euro\">
                        <?php echo e($meal->preis_intern); ?>

                    </td>
                    <td class=\"preis-euro\">
                        <?php echo e($meal->preis_extern); ?>

                    </td>
                    <td>
                        <small>
                            <?php $__currentLoopData = $allergenList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allergen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($allergen->gericht_id == $meal->id): ?>
                                    [<?php echo $allergen->code; ?>]
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </small>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr class=dots>
                <td>
                    <p>...</p>
                </td>
                <td>
                    <p>...</p>
                </td>
                <td>
                    <p>...</p>
                </td>
                <td>
                    <p>...</p>
                </td>
            </tr>
            </tbody>
            <tfoot>

                    <td>
                        <a href="/meals/allergyList" style="text-align: center">Klicke hier für die liste aller Allergene</a>
                    </td>

            </tfoot>
        </table>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mortimer/Documents/Studium/DBWT_2020/meilenstein_4/emensa/resources/views/Homepage/meals.blade.php ENDPATH**/ ?>