<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class gericht_hat_kategorie extends Model
{
    use HasFactory;
}
